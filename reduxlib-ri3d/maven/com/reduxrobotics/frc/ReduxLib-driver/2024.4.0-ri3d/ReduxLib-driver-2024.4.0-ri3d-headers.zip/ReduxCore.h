// Copyright (c) Redux Robotics
// This header is open source and can be modified and shared under the 3-clause BSD license.
// However, the driver it binds to is all rights reserved -- see LICENSE-driver.txt for more information.

#pragma once
#include <stdint.h>
#include <stddef.h>

/**
 * ReduxCore.h: the entire driver API surface (and the only header to be included with the driver)
 * 
 * This gets exposed to the c/cpp api.
*/
#ifdef __cplusplus
extern "C" {
#endif

/**
 * Core CAN struct message. Used by the driver to represent CAN packets.
*/
#ifdef _MSC_VER
#pragma pack(push, 4)
struct ReduxCore_CANMessage {
#else
struct __attribute__((packed, aligned(4))) ReduxCore_CANMessage {
#endif
    uint32_t messageID; // full 32-bit message id
    uint8_t canBusID; // index of the can bus the message is pulled from (usually 0)
    uint8_t dataSize; // length of the data (0-8)
    uint8_t pad[2]; // pad bytes (reserved)
    uint64_t timestamp; // 64-bit timestamp relative to the FPGA clock (microseconds)
    uint8_t data[8]; // CAN packet data
};
#ifdef _MSC_VER
#pragma pack(pop)
#endif

/**
 * Returns the version number. This number is unique per version.
 * Minor version is bits 0-7
 * Major version is bits 8-15
 * Year is bits 16-30
 * 
 * @return version number integer
*/
int ReduxCore_GetVersion();

/**
 * Inits the Redux CANLink server that serves the frontend's websocket and provides CAN messages to the vendordep.
 * This is generally called by the CanandEventLoop in either C++ or Java and doesn't need to be directly called.
 * This function is idempotent and will do nothing if called multiple times.
 * 
 * @return 0 on success, -1 on already started
*/
int ReduxCore_InitServer();

/**
 * Stops the Redux CANLink server. 
 * This is called by CanandEventLoop to stop CANLink.
 * 
 * @return 0 on success, -1 on already started
*/
int ReduxCore_StopServer();

/**
 * Sends a CAN message to the bus with the specified handle ID. 
 * 
 * Currently only supports bus 0 (the Rio's bus) so it directly calls HAL_CAN_SendMessage and returns the status
 * 
 * @param[in] canBusID bus id to send to
 * @param[in] messageID message ID to send
 * @param[in] data the data associated with the message
 * @param[out] dataSize the message data size (0-8)
 * @return 0 on success, negative on failure.
*/
int ReduxCore_EnqueueCANMessage(uint8_t canBusID, uint32_t messageID, const uint8_t* data, uint8_t dataSize);

/**
 * Sends multiple CAN messages to the bus with the specified handle ID. 
 * 
 * @param[in] messages array of messages to send
 * @param[in] messageCount number of messages to queue
 * @param[out] messagesSent number of messages actually sent
 * @return 0 on success, negative on failure.
*/
int ReduxCore_BatchEnqueueCANMessages(struct ReduxCore_CANMessage* messages, size_t messageCount, size_t* messagesSent);

/**
 * Sends multiple CAN messages to the bus with the specified handle ID. 
 * 
 * @param[out] messages array of messages to receive into
 * @param[in] messageCount the maximum number of messages to receive
 * @param[out] messagesSent number of messages actually received
 * @return 0 on success, negative on failure.
*/
int ReduxCore_BatchWaitForCANMessages(struct ReduxCore_CANMessage* messages, size_t messageCount, size_t* messagesRead);

/**
 * Blocks until a CAN message has been received by CANLink server and writes the result to msgBuf.
 * 
 * @param[out] msgBuf message pointer to receive into
 * @return 0 on success, negative on failure. A value of -1 indicates the server has shut down.
*/
int ReduxCore_WaitForCANMessage(struct ReduxCore_CANMessage* msgBuf);

#ifdef __cplusplus
}  // extern "C"
#endif
